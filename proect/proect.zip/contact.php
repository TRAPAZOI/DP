<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="script.js" defer></script>
    <link rel="stylesheet" href="style.css">

    <title>Ваш сайт</title>
</head>
<body>
    <header>
        <nav>
        <a href="index.php">Главная</a>
            <a href="onas.php">О нас</a>
            <a href="produkt.php">Продукт</a>
</nav>     
    </header>
    <div class="image-caption">О нашей компании</div>
   

<section>
    
<p>Контакты:</p>
<p>Адрес: 346630, Ростовская область, р-н Семикаракорский,г. Семикаракорск, ул.Придонская, д.24  </p>
<p>Время работы: ПН-ПТ с 8:00 до 18:00</p>

<p>Побегайлова Наталья Николаевна  8 (928) 757-29-55</p>

<p>Почта: pobegailova78@mail.ru</p>
</section>
</body>
</html>